// Preload script (currently empty but here for future native integrations)
window.addEventListener('DOMContentLoaded', () => {
  // Example: expose safe APIs to renderer if needed
});
