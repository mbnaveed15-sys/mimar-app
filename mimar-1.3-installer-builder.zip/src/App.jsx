import React from 'react'
import PlannerApp from './components/PlannerApp'

export default function App(){
  return <PlannerApp />
}
